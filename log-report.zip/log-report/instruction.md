Analyze the Apache access log located at /app/access.log.

Write a JSON report to /app/report.json.

The report must contain the following fields:

- total_requests
- unique_ips
- top_path

Success criteria:

1. Create a valid JSON file at /app/report.json.
2. The total_requests field equals the number of log entries.
3. The unique_ips field equals the number of unique client IP addresses.
4. The top_path field equals the most frequently requested request path.